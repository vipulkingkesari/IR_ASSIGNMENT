# Information Retrival
## Assignment 1, Group 42
### Team Members: Harsh Bandhey, Md Talib, Arshdeep Singh

-----------------------------------

#### Question 1, Positional Index